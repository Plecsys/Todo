
# -*- coding: utf-8 -*-

import time
from odoo import api, fields, models

class ReportCalendarMeetingReport(models.AbstractModel):
    _name = 'report.odoo_pet_sitting.pet_sitting_calendar_meeting_report_id'

    @api.model
    def render_html(self,docids, data=None):
        attendance_ids = data['ids']
        docargs = {
            'doc_ids': attendance_ids,
            'doc_model': 'calendar.event',
            'docs': self.env['calendar.event'].browse(attendance_ids),
            'data':data,
        }
        return self.env['report'].render('odoo_pet_sitting.pet_sitting_calendar_meeting_report_id', docargs)


# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
