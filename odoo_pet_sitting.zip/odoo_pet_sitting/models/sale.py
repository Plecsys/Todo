# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'
    
    serviceprovider_id = fields.Many2one(
        'res.partner',
        string='Walker / Sitter',
    )
    
    @api.multi #Pass value of client to pay in create invoice.
    def _prepare_invoice_line(self, qty):
       res = super(SaleOrderLine, self)._prepare_invoice_line(qty)
       if self.serviceprovider_id:
           vals = {
               'serviceprovider_id': self.serviceprovider_id.id,
           }
           res.update(vals)
       return res

class SaleOrder(models.Model):
    _inherit = 'sale.order'
    
    @api.multi
    @api.depends()
    def _meeting_count(self):
        for rec in self:
            meetings = self.env['calendar.event'].search([('sale_id','=',rec.id)])
            rec.meeting_count = len(meetings)
            
    schedule_id = fields.Many2one(
        'calendar.event',
        string='Sitting Appointment Reference',
        readonly=True,
    )
    pets_ids = fields.Many2many(
        'pet.information',
        string='Pet',
    )
    meeting_count = fields.Integer(
        compute = '_meeting_count',
        string = 'Meetings',
    )
    
    @api.multi
    def show_meeting(self):
        for rec in self:
            res = self.env.ref('calendar.action_calendar_event')
            res = res.read()[0]
            res['domain'] = str([('sale_id','=',rec.id)])
        return res
        
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
