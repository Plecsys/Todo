# -*- coding: utf-8 -*-

from odoo import models, fields
from datetime import datetime,date

class PetVaccine(models.Model):
    _name = 'pet.vaccine'
    _description = 'Pet Vaccine'
    _order = 'id desc'
    
    description = fields.Text(
        string='Description',
        required=True,
    )
    date_expire = fields.Date(
        string="Date Expire",
        required=True,
    )
    date_administered = fields.Date(
        string="Date Administered",
        required=True,
    )
    veterinarian_id = fields.Many2one(
        'res.partner',
        string='Veterinarian',
        required=True,
    )
    petvaccine_id = fields.Many2one(
        'pet.information',
    )

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
