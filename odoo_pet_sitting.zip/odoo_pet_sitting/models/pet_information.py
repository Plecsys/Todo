# -*- coding: utf-8 -*-

from odoo import models, fields, api
from datetime import datetime,date

class PetInformation(models.Model):
    _name = 'pet.information'
    _description = 'Pet Detail'
    _order = 'id desc'
    _inherit = ['mail.thread', 'ir.needaction_mixin']
    
    @api.onchange('birthdate')
    def _onchange_bdate(self):
       if self.birthdate:
           today = date.today()
           bday = datetime.strptime(self.birthdate, '%Y-%m-%d')
           self.age = today.year - bday.year - ((today.month, today.day) < (bday.month, bday.day))
             
    name = fields.Char(
        string='Number', 
        default='New',
        copy=False, 
    )
    image_medium = fields.Binary(
        string="Image",
        attachment=True,
    )
    image1 = fields.Binary(
        string="Photo1",
    )
    image2 = fields.Binary(
        string="Photo2",
    )
    image3= fields.Binary(
        string="Photo3",
    )
    image4 = fields.Binary(
        string="Photo4",
    )
    image5 = fields.Binary(
        string="Photo5",
    )
    image6 = fields.Binary(
        string="Photo6",
    )
    image7 = fields.Binary(
        string="Photo7",
    )
    image8 = fields.Binary(
        string="Photo8",
    )
    image9 = fields.Binary(
        string="Photo9",
    )
    image10 = fields.Binary(
        string="Photo10",
    )
    customer_id = fields.Many2one(
        'res.partner',
        string="Customer", 
        required=True,
    )
    pet_name = fields.Char(
        string="Name",
        required=True
    )
    birthdate = fields.Date(
        string="Birth Date",
        copy=False,
    )
    age = fields.Integer(
        string="Age",
        copy=False,
    )
    sex = fields.Selection(
        [('male', 'Male'),
        ('female', 'Female')],
        string='Sex',
        required=True,
    )
    breed = fields.Many2one(
        'pet.type',
        string="Pet Type",
        required=True,
    )
    color = fields.Char(
        string="Color"
    )
    problem = fields.Text(
        string="Has your pet had any previous medical or surgical problems? If yes, please explain."
    )
    allergic = fields.Boolean(
        string="Has your pet ever had an allergic reaction to a medication? "
    )
    reaction = fields.Boolean(
        string="Has your pet ever had a reaction to a vaccine?"
    )
    medication = fields.Text(
        string="Is your pet on any medication? If yes, please list."
    )
    stay = fields.Selection(
        [('inside', 'Inside'),
        ('outside', 'Outside'),
        ('inout', 'Inside and Outside')],
        string='Stay',
        default='inside',
    )
    feed = fields.Text(
        string="What do you feed your pet?",
    )
    veterinarian_id = fields.Many2one(
        'res.partner',
        string='Veterinarian',
    )
    contact_veter  = fields.Boolean(
        string="May we contact them for medical information if needed?",
    )
    rabies = fields.Datetime(
        string='Rabies Vaccine',
        default=fields.Datetime.now,
    )
    distemper = fields.Datetime(
        string='Distemper / Parvo Virus',
        default=fields.Datetime.now,
    )
    bordetella = fields.Datetime(
        string='Bordetella (Kennel cough)',
        default=fields.Datetime.now,
    )
    heartworm = fields.Datetime(
        string='Heartworm Test',
        default=fields.Datetime.now,
    )
    heartworm_preventative = fields.Datetime(
        string='Heartworm Preventative',
        default=fields.Datetime.now,
    )
    flea_preventative = fields.Datetime(
        string='Flea Preventative',
        default=fields.Datetime.now,
    )
    stool_check = fields.Datetime(
        string='Stool check',
        default=fields.Datetime.now,
    )
    circle = fields.Selection(
        [('pet_store', 'Pet Store'),
        ('private_home', 'Private Home'),
        ('breeder', 'Breeder'),
        ('stray', 'Stray'),
        ('human', 'Humane Society'),
        ('other', 'other')],
        string='Where did your pet come from? (Circle one)',
    )
    petvaccine_ids = fields.One2many(
        'pet.vaccine',
        'petvaccine_id',
        string='Pet Vaccinations',
    )
    
    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('pet.information') or 'New'
        return super(PetInformation, self).create(vals)

    @api.multi
    def show_service(self):
        for rec in self:
            saler = self.env['calendar.event']
            res = self.env.ref('calendar.action_calendar_event')
            res = res.read()[0]
            res['domain'] = str([('pets_ids','=',rec.id)])
        return res

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
