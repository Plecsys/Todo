# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import Warning

class CalendarMeeting(models.TransientModel):
    _name = 'calendar.meeting.report'

    start_date = fields.Date(
        string='Meeting Start Date', 
        required=True, default=fields.date.today()
    )
    end_date = fields.Date(
        string='Meeting End Date', 
        required=True, 
        default=fields.date.today()
    )
    user_id = fields.Many2one(
        'res.users',
        string='Walker/Sitter',
        required=True,
    )

    @api.multi
    def print_meeting_report(self):
        meeting_obj = self.env['calendar.event']
        meeting_record = meeting_obj.search([('start_datetime','>=',self.start_date), ('stop', '<=', self.end_date)])
        meeting_data = {}
        meeting_ids = []
        for rec in meeting_record:
            if rec.id not in meeting_data:
                meeting_ids.append(rec.id)
                meeting_data[rec.id] = [{'petcare' : self.user_id.name,'name' : rec.name}]
            else:
                meeting_data[rec.id].append({'location' : rec.location,'name' : rec.name})
        data = self.read()[0]
        data['ids'] = meeting_ids
        data['model'] = 'calendar.event'
        data['meeting_data'] = meeting_data
        data['petcare'] = self.user_id.name
        act = self.env['report'].get_action(self, 'odoo_pet_sitting.pet_sitting_calendar_meeting_report_id', data=data)
        return act

#vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
