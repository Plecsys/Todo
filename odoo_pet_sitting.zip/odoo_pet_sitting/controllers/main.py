# -*- coding: utf-8 -*-
import base64

from odoo import http, _
from odoo.http import request
from odoo.addons.website_portal.controllers.main import website_account

class website_account(website_account):

    @http.route()
    def account(self, **kw):
        """ Add meeting documents to main account page """
        response = super(website_account, self).account(**kw)
        partner = request.env.user.partner_id
        meeting_obj = http.request.env['calendar.event']
        pet_obj = http.request.env['pet.information']
        meeting_count = meeting_obj.sudo().search_count([
                ('partner_ids', 'child_of', [partner.commercial_partner_id.id])
        ])
        pet_count = pet_obj.sudo().search_count([
               ('customer_id', 'child_of', [partner.commercial_partner_id.id])
        ])
        response.qcontext.update({
        'meeting_count': meeting_count,
        'pet_count': pet_count,
        })
        return response
        
    @http.route(['/my/meetings', '/my/meetings/page/<int:page>'], type='http', auth="user", website=True)
    def portal_my_meeting(self, page=1, **kw):
        response = super(website_account, self)
        values = self._prepare_portal_layout_values()
        partner = request.env.user.partner_id
        meeting_obj = http.request.env['calendar.event']
        domain = ['|', 
             ('partner_ids', 'child_of', [partner.commercial_partner_id.id]),
             ('partner_ids', 'in', [partner.id])
          ]
        # count for pager
        meeting_count = meeting_obj.sudo().search_count(domain)
        # pager
        pager = request.website.pager(
            url="/my/meetings",
            total=meeting_count,
            page=page,
            step=self._items_per_page
        )
        # content according to pager and archive selected
        meetings = meeting_obj.sudo().search(domain)#, limit=self._items_per_page, offset=pager['offset']
        print "meetings///",meetings
        values.update({
            'meetings': meetings,
            'page_name': 'meeting',
            'pager': pager,
            'default_url': '/my/meetings',
        })
        return request.render("odoo_pet_sitting.display_meetings", values)
       
    @http.route(['/my/meeting/<model("calendar.event"):meeting>'], type='http', auth="user", website=True)
    def my_meeting(self, meeting=None, **kw):
        meetings = http.request.env['calendar.event'].sudo().browse(meeting.id)
        return request.render("odoo_pet_sitting.display_meeting", {'meeting': meeting, 'user': request.env.user})
        
    @http.route(['/my/pets', '/my/pets/page/<int:page>'], type='http', auth="user", website=True)
    def portal_my_pet(self, page=1, **kw):
        response = super(website_account, self)
        values = self._prepare_portal_layout_values()
        partner = request.env.user.partner_id
        pet_obj = http.request.env['pet.information']
        domain = [
        #'|', 
             #('partner_ids', 'child_of', [partner.commercial_partner_id.id]),
             ('customer_id', 'in', [partner.id])
          ]
        # count for pager
        pet_count = pet_obj.sudo().search_count(domain)
        print '==============pet_count==================',pet_count
        # pager
        pager = request.website.pager(
            url="/my/pets",
            total=pet_count,
            page=page,
            step=self._items_per_page
        )
        # content according to pager and archive selected
        pets = pet_obj.sudo().search(domain, limit=self._items_per_page, offset=pager['offset'])
        print '=================pets==================',pets 
        values.update({
            'pets': pets,
            'page_name': 'pet',
            'pager': pager,
            'default_url': '/my/pets',
        })
        print 'values============================>',values
        return request.render("odoo_pet_sitting.display_pets", values)
       
    @http.route(['/my/pet/<model("pet.information"):pet>'], type='http', auth="user", website=True)
    def my_pet(self, pet=None, **kw):
        pet_obj = http.request.env['pet.information'].sudo().browse(pet.id)
        attachment_list = request.httprequest.files.getlist('attachment')
        for image in attachment_list:
            if kw.get('attachment'):
                attachments = {
                           'res_name': image.filename,
                           'res_model': 'pet.information',
                           'res_id': pet.id,
                           'datas': base64.encodestring(image.read()),
                           'type': 'binary',
                           'datas_fname': image.filename,
                           'name': image.filename,
                       }
                attachment_obj = http.request.env['ir.attachment']
                attachment_obj.sudo().create(attachments)
        if len(attachment_list) > 0:
            group_msg = _('Customer has sent %s attachments of pet. Name of attachments are: ') % (len(attachment_list))
            for attach in attachment_list:
                group_msg = group_msg + '\n' + attach.filename
            group_msg = group_msg + '\n'  +  '. You can see top attachment menu to download attachments.'
            pet_obj.sudo().message_post(body=group_msg,message_type='comment')
            customer_msg = _('%s') % (kw.get('pet_comment'))
            pet_obj.sudo().message_post(body=customer_msg,message_type='comment')
            return http.request.render('odoo_pet_sitting.successful_pet_send',{
            })
        if kw.get('pet_comment'):
            customer_msg = _('%s') % (kw.get('pet_comment'))
            pet_obj.sudo().message_post(body=customer_msg,message_type='comment')
            return http.request.render('odoo_pet_sitting.successful_pet_send',{
            })
        return request.render("odoo_pet_sitting.display_pet", {'pet': pet, 'user': request.env.user})
        
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

