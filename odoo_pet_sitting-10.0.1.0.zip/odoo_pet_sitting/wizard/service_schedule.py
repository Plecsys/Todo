# -*- coding: utf-8 -*-

from odoo import models, fields, api

class ServiceSchedule(models.TransientModel):
    _name = 'service.schedule'
    
    attendee_ids = fields.Many2many(
        'res.partner',
        string='Attendees / Carrers',
        required=True,
        #default=lambda self: self.env.user,
    )
    location = fields.Char(
        string = 'Location',
        required=True,
    )
    owner_id = fields.Many2one(
        'res.users',
        string = 'Walker/Sitter',
        required=True,
    )
    sale_description = fields.Char(
        string = 'Schedule Description',
        required=True,
    )
#     calendar_id = fields.Many2one(
#         'calendar.event',
#         string='event',
#         readonly=True,
#     )
    pets_ids = fields.Many2many(
        'pet.information',
        string='Pet',
        required=True,
    )
    service_ids = fields.Many2many(
        'product.product',
        string='Services',
        required=True,
    )
    
    @api.multi
    def create_schedule(self):
        active_id = self._context.get('active_id')
        calendar_obj = self.env['calendar.event']
        vals = {
                'name': self.sale_description,
                'partner_ids' : [(6, 0, [self.attendee_ids.ids])],
                'user_id' : self.owner_id.id,
                'location' : self.location,
                'pets_ids' : [(6, 0, [self.pets_ids.ids])],
                'service_ids' : [(6, 0, [self.service_ids.ids])],
                'sale_id' : active_id,
                'start': fields.Datetime.now(),
                'start_datetime' : fields.Datetime.now(),
                'stop': fields.Datetime.now(),
                    }
        calendar_id = calendar_obj.create(vals)
        active_id = self._context.get('active_id')
        sale_obj = self.env['sale.order'].browse(active_id)
        vals1 = {
                'schedule_id': calendar_id.id,
                }
        sale_obj.write(vals1)
        res = self.env.ref('calendar.action_calendar_event')
        res = res.read()[0]
        res['domain'] = str([('id','=',calendar_id.id)])
        return res
        
    @api.onchange('attendee_ids')
    def _compute_pet(self):
        for rec in self:
            return {'domain' : {'pets_ids':[('customer_id','in', rec.attendee_ids.ids)]}}
        
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
            
