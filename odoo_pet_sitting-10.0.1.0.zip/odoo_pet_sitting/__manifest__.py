# -*- coding: utf-8 -*-

# Part of Probuse Consulting Service Pvt Ltd. See LICENSE file for full copyright and licensing details.

{
    'name': "Pet Sitting / Dog-Animal Walking-Sitting App",
    'version': '1.0',
    'price': 99.0,
    'live_test_url':'https://youtu.be/Th_z1E5hcXc',
    'currency': 'EUR',
    'license': 'Other proprietary',
    'summary': """This module allow your company to manage pet sitting and dog/animal walking business.""",
    'description': """
Odoo Pet Sitting
This module maintain pet service
Pet Information
Pet Detail
Customer Information
Pet Type
just dog
pet sitter
pet care
dog care
animal care
bird care
care pet
import pet
export pet
import export pet
animal pet
Dog walking
Pet sitters
Dog daycare

pet sitting business
pet sitting rates
Cat Feeding
Minding
how-to-start-a-pet-sitting-business
Pet Sitting / Dog-Animal Walking and Sitting Business Management App
This module allow your company to manage pet sitting and dog/animal walking business.
Created Menus :
Pet
Pet Information
Pets
Customer
Clients
Veterinarian
Veterinarians
Pet Services
Service Templates
Services
Walker / Sitter
Walkers / Sitters
Configuration
Working Times
Pet Types
Defined Reports
Print Pet Information
Print Meeting
dog walk
pet walk
pet
dog
animal
Walkers
Sitters
Customer can request pet services to your company.
Sales team can create quote for requested services by customer and send to your customer.
On confirmation of quote, sales team can assign sitter/walker to do job for those services selected on order lines.
Sales team can schedule pet sitting schedules which create jobs for sitter and walkers - This is Odoo meeting module which is going to use extensivly in this app.
Sales person can run wizard to create pet schedule and assign job to sitter and walkers.
Two new groups are created to manage this app: 1. Pet User and 2. Pet Manager 
Pet manager can schedule repeated meetings/appoinment for pet based on order they have received from customer and bookings.
Pet information can be store with image of pet and more photos.
Pet types can be created and link with pet information.
Full Pet Vacacines details on Pet.
You can manage your clients, accounting, billings, Payroll, Order and all other Odoo apps to manage your pet business along with our app.
Product will act as pet service and you configure costing for that services of pet business. - Your customer can view schedules in website portal my account page and they can also view details of their pet from website. - For more details please watch video.




    """,
    'category' : 'Extra Tools',
    'author': "Probuse Consulting Service Pvt. Ltd.",
    'website': "http://www.probuse.com",
    'support': 'contact@probuse.com',
    'images': ['static/description/img1.jpg'],
    'depends': ['base',
                'calendar',
                'sales_team',
                'product',
                'sale',
                'website',
                'website_portal',
                'resource',
                'document',
                ],
    'data':[
        'security/security.xml',
        'security/ir.model.access.csv',
        'data/pet_sequence.xml',
        'data/type_data.xml',
        'wizard/schedule_wizard.xml',
        'wizard/calendar_meeting.xml',
        'views/product_template_views.xml',
        'views/pet_information_view.xml',
        'views/partner_view.xml',
        'views/pet_type_view.xml',
        'views/calendar_views.xml',
        'views/sale_views.xml',
        'views/account_invoice_view.xml',
        'views/template.xml',
        'views/my_pet_template.xml',
        'views/my_meeting_template.xml',
        'views/pets_attachments_template.xml',
        'views/successfull_template.xml',
        'report/pet_report.xml',
        'report/report_reg.xml',
        'report/report_calendar_meeting.xml',
        
    ],
    'qweb': [
        'static/src/xml/*.xml',
    ],
    'installable' : True,
    'application' : False,
}

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
