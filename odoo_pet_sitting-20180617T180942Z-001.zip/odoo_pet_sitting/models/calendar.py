# -*- coding: utf-8 -*-

from odoo import fields, models

class Meeting(models.Model):
    _inherit = 'calendar.event'
    
    service_ids = fields.Many2many(
        'product.product',
        string='Service',
    )
    sale_id = fields.Many2one(
        'sale.order',
        string = 'Sales Order',
        readonly = True,
        copy = False,
    )
    pets_ids = fields.Many2many(
        'pet.information',
        string='Pet',
    )
    user_name = fields.Many2one(
        'res.users',
        related = "user_id",
    )

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
