# -*- coding: utf-8 -*-

from odoo import models, fields, api

class Partner(models.Model):
    _inherit = 'res.partner'
    
    @api.multi
    @api.depends('pet_ids')
    def _pet_count(self):
        for rec in self:
            rec.pet_count = len(rec.pet_ids)
            
    pet_ids = fields.One2many(
        'pet.information',
        'customer_id',
        string='Pets',
        readonly=True,
    )
    pet_count = fields.Integer(
        compute = '_pet_count',
        store=True,
     )
    is_veterinarian = fields.Boolean(
        string='Is Veterinarian?',
        default=False,
        copy=True,
    )
    is_pet_serviceprovider = fields.Boolean(
        string='Is Walker / Sitter?',
        default=False,
        copy=True,
    )
    working_time = fields.Many2one(
        'resource.calendar',
        string='Working Time',
    )
    @api.multi
    def show_pet(self):
        for rec in self:
            res = self.env.ref('odoo_pet_sitting.action_pet_informtion')
            res = res.read()[0]
            res['domain'] = str([('customer_id','=',rec.id)])
        return res

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
