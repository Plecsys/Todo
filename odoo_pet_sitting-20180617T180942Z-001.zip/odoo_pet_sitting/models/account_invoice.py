# -*- coding: utf-8 -*-

from odoo import models, fields

class AccountInvoiceLine(models.Model):
    _inherit = 'account.invoice.line'
    
    serviceprovider_id = fields.Many2one(
        'res.partner',
        string='Walker / Sitter',
    )
    
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
