# -*- coding: utf-8 -*-

import pet_type
import pet_information
import res_partner
import calendar
import sale
import product_template
import pet_vaccine
import account_invoice

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
